
## Plan: PassardAutoMediaJa v2 — Accounts, Moderation, Premium

### 1. Logo swap
- Upload your PMxJA logo as a Lovable Asset and use it in `SiteHeader`, favicon, and OG meta. Existing inline icon mark gets replaced everywhere.

### 2. Enable Lovable Cloud + Auth
- Turn on Cloud (Supabase under the hood).
- Email/password + Google sign-in.
- New `_authenticated/` route subtree for protected pages (sell, dashboard, admin).
- `/auth` page with sign-in/sign-up.
- `onerushwave@gmail.com` auto-granted `admin` role on first signup via DB trigger.

### 3. Database schema (migration)
- `profiles` — id (= auth.uid), display_name, dealership_name, phone, whatsapp, avatar_url, bio, location, verified, created_at.
- `user_roles` + `app_role` enum (`user`, `admin`) + `has_role()` SECURITY DEFINER fn (per security rules — roles never on profiles).
- `listings` — id, seller_id, kind (`car`|`part`), title, description, price, year, make, model, mileage, condition, location, images (text[]), tier (`free`|`premium`|`premium_plus`), status (`pending`|`approved`|`rejected`|`sold`), rejection_reason, promo_video_url, views, created_at.
- `payments` — id, user_id, listing_id (nullable), tier, amount, method (`stripe`|`bank`|`paypal`|`direct_debit`), provider_ref, proof_url, status (`pending`|`verified`|`rejected`), reviewed_by, created_at.
- Storage buckets: `listing-images` (public), `payment-proofs` (private), `avatars` (public).
- RLS everywhere; public can SELECT only `approved` listings + public profile fields. Admins use `has_role()`.

### 4. Seller profiles
- `/dashboard` — my listings, my payments, edit profile, upload avatar.
- `/seller/$id` — public seller page: avatar, dealership info, WhatsApp button, verified badge, grid of their approved listings.
- Sell form pre-fills seller info from profile.

### 5. Upload moderation
- New listings save with `status='pending'`. Browse hides pending.
- `/admin` route (admin-only): tabs for **Listings queue** and **Payments queue**.
- Approve / reject with reason; reject sends listing back to seller's dashboard for edit.

### 6. Payment verification (both flows)
- **Stripe (deferred)** — Stripe-managed checkout requires the **Pro plan**. I'll wire the UI button + edge handler stub but leave activation off until you upgrade. I'll show a clear "Upgrade to enable instant payments" notice on the pricing page until then.
- **Manual proof** — buyer of Premium/Premium+ uploads receipt screenshot + transaction ID after bank transfer / PayPal / direct debit. Lands in admin Payments queue. On approve → listing tier upgraded + premium features unlocked.

### 7. Premium gating
- Free: standard listing, basic gallery, 360° viewer.
- Premium ($10.55): "Featured" badge + priority sort + social-review request form + queued for your manual social post.
- Premium+ ($25.65): everything in Premium + **AI promo video generation** + unlimited edits + top-of-page placement + verified seller badge.
- Server-side checks: AI video endpoint and feature flags verify `tier='premium_plus'` via authenticated server fn (no client trust).

### 8. AI promo video flow (Premium+ only)
- On a Premium+ listing detail page, "Generate AI Promo Video" button.
- Server fn (auth + tier gated) calls Lovable AI video model with prompt built from listing data + first image as starting frame: cinematic 5s 1080p clip.
- Saves to `listing-images` bucket, attaches `promo_video_url`. Plays inline + downloadable for the seller to repost.

### 9. Chatbot
- Keep existing AI concierge; teach it about auth state, profile, and pending listings. WhatsApp handoff unchanged (`8768598983`).

### Technical notes
- Stack: TanStack Start server fns (no Edge Functions for app logic), `requireSupabaseAuth` middleware, `attachSupabaseAuth` already wired by integration.
- Loaders for public pages call publishable-client server fns; `_authenticated/` loaders call auth-gated fns.
- All admin actions verify `has_role(auth.uid(),'admin')` server-side before privileged ops.
- AI video uses your existing `LOVABLE_API_KEY` — no extra secrets needed.
- Stripe enablement happens later via `enable_stripe_payments` once you're on Pro.

### Out of scope for this turn
- Real-time chat between buyer/seller (WhatsApp already covers it).
- Email notifications on approval (can add next).
- Payouts/escrow — payments are advertising fees to you, not buyer↔seller.

Reply **go** and I'll build it. Anything to change first?
