import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getApprovedListings } from "@/lib/listings.functions";
import { TIER_LABEL } from "@/lib/db-types";
import { Car, Wrench, MapPin, Phone, Crown, Sparkles, BadgeCheck } from "lucide-react";

export const Route = createFileRoute("/browse")({
  head: () => ({
    meta: [
      { title: "Browse Cars & Auto Parts — PassardAutoMediaJa" },
      { name: "description", content: "Browse cars, trucks and auto parts for sale across Jamaica. Vetted listings, updated daily." },
    ],
  }),
  component: Browse,
});

function Browse() {
  const fetchFn = useServerFn(getApprovedListings);
  const { data: items = [], isLoading } = useQuery({
    queryKey: ["listings-approved"],
    queryFn: () => fetchFn(),
  });
  const [filter, setFilter] = useState<"all" | "car" | "part">("all");
  const filtered = items.filter((i) => filter === "all" || i.kind === filter);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold">Browse listings</h1>
          <p className="text-muted-foreground text-sm mt-1">Vetted cars and auto parts from sellers across Jamaica.</p>
        </div>
        <div className="flex gap-1 rounded-lg bg-secondary p-1">
          {(["all", "car", "part"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium capitalize ${
                filter === k ? "bg-card shadow-card text-primary" : "text-muted-foreground"
              }`}
            >
              {k === "all" ? "All" : k === "car" ? "Cars" : "Parts"}
            </button>
          ))}
        </div>
      </div>

      {isLoading && <p className="mt-8 text-sm text-muted-foreground">Loading…</p>}

      <div className="grid gap-5 mt-8 sm:grid-cols-2 lg:grid-cols-3">
        {!isLoading && filtered.length === 0 && (
          <div className="col-span-full rounded-xl border-2 border-dashed border-border p-10 text-center text-muted-foreground">
            No approved listings yet. <Link to="/sell" className="text-primary font-medium">Post the first one</Link>.
          </div>
        )}
        {filtered.map((l) => {
          const isPlus = l.tier === "premium_plus";
          const isPrem = l.tier === "premium";
          return (
            <article
              key={l.id}
              className={`group rounded-xl bg-card border overflow-hidden transition-shadow flex flex-col ${
                isPlus
                  ? "border-primary/60 shadow-soft ring-2 ring-primary/20"
                  : isPrem
                  ? "border-primary/30 shadow-card"
                  : "border-border shadow-card hover:shadow-soft"
              }`}
            >
              <div className="aspect-video bg-sky-soft relative overflow-hidden">
                {l.image_urls?.[0] ? (
                  <img src={l.image_urls[0]} alt={l.title} className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform" />
                ) : (
                  <div className="grid place-items-center h-full text-primary/40">
                    {l.kind === "car" ? <Car className="h-16 w-16" /> : <Wrench className="h-16 w-16" />}
                  </div>
                )}
                <span className="absolute top-3 left-3 px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wide font-semibold bg-primary text-primary-foreground">
                  {l.kind === "car" ? "Vehicle" : "Auto Part"}
                </span>
                {isPlus && (
                  <span className="absolute top-3 right-3 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] uppercase font-bold bg-gradient-to-r from-primary to-accent text-primary-foreground shadow">
                    <Sparkles className="h-3 w-3" /> Premium+
                  </span>
                )}
                {isPrem && (
                  <span className="absolute top-3 right-3 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] uppercase font-bold bg-white/95 text-primary shadow">
                    <Crown className="h-3 w-3" /> Premium
                  </span>
                )}
              </div>
              <div className="p-4 flex flex-col gap-2 flex-1">
                <h3 className="font-semibold leading-tight">{l.title}</h3>
                <div className="text-primary font-bold">{l.price}</div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" /> {l.location}
                </div>
                {l.seller && (
                  <Link
                    to="/seller/$id"
                    params={{ id: l.seller.id }}
                    className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1"
                  >
                    by {l.seller.dealership_name || l.seller.display_name || "Seller"}
                    {l.seller.verified && <BadgeCheck className="h-3 w-3 text-primary" />}
                  </Link>
                )}
                <p className="text-sm text-muted-foreground line-clamp-2 mt-0.5">{l.description}</p>
                <div className="mt-auto pt-3 flex gap-2">
                  <a
                    href={`https://wa.me/${(l.seller?.whatsapp ?? "18768598983").replace(/\D/g, "")}?text=${encodeURIComponent(`Hi, I'm interested in your "${l.title}" on PassardAutoMediaJa.`)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-[oklch(0.65_0.18_150)] text-white px-3 py-2 text-sm font-medium hover:opacity-95"
                  >
                    <Phone className="h-4 w-4" /> WhatsApp
                  </a>
                </div>
                {l.promo_video_url && (
                  <span className="text-[10px] uppercase font-bold text-primary mt-1 inline-flex items-center gap-1">
                    <Sparkles className="h-3 w-3" /> AI promo asset attached
                  </span>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
