import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Crown, Sparkles, Building2, CreditCard, Wallet } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Premium & Premium+ — PassardAutoMediaJa" },
      { name: "description", content: "Boost your listings with Premium personal reviews ($10.55) or Premium+ unlimited AI ads ($25.65, normally $299.45)." },
    ],
  }),
  component: Pricing,
});

function Pricing() {
  return (
    <div className="bg-sky-soft">
      <div className="mx-auto max-w-7xl px-4 py-14">
        <div className="text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-semibold">
            <Sparkles className="h-3.5 w-3.5" /> Free forever — upgrade only if you want a boost
          </div>
          <h1 className="mt-4 text-4xl md:text-5xl font-extrabold">Choose your plan</h1>
          <p className="mt-3 text-muted-foreground">Posting ads is always free. Premium gets your car seen.</p>
        </div>

        <div className="grid gap-6 mt-12 md:grid-cols-3">
          {/* Free */}
          <div className="rounded-2xl bg-card border border-border p-7 shadow-card">
            <h3 className="text-lg font-bold">Free</h3>
            <p className="text-sm text-muted-foreground mt-1">For all dealers & private sellers.</p>
            <div className="mt-5"><span className="text-4xl font-extrabold">$0</span></div>
            <ul className="mt-5 space-y-2 text-sm">
              {["Unlimited car & parts listings", "Upload your own photos", "WhatsApp lead button", "AI concierge chatbot"].map((f) => (
                <li key={f} className="flex gap-2"><Check className="h-4 w-4 text-primary mt-0.5" />{f}</li>
              ))}
            </ul>
          </div>

          {/* Premium */}
          <div className="rounded-2xl bg-card border-2 border-primary/40 p-7 shadow-soft relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold">Popular</div>
            <h3 className="text-lg font-bold flex items-center gap-2"><Crown className="h-5 w-5 text-primary" />Premium</h3>
            <p className="text-sm text-muted-foreground mt-1">Personal review on Passard's socials for instant recognition.</p>
            <div className="mt-5"><span className="text-4xl font-extrabold">$10.55</span><span className="text-muted-foreground"> /listing</span></div>
            <ul className="mt-5 space-y-2 text-sm">
              {[
                "Personally reviewed by Passard",
                "Featured on Passard's social media",
                "Instant exposure & engagement boost",
                "Unlike a dead scene — real reach",
              ].map((f) => (
                <li key={f} className="flex gap-2"><Check className="h-4 w-4 text-primary mt-0.5" />{f}</li>
              ))}
            </ul>
            <Link to="/checkout/$tier" params={{ tier: "premium" }} className="mt-6 block text-center rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
              Get Premium — $10.55
            </Link>
          </div>

          {/* Premium+ */}
          <div className="rounded-2xl bg-hero text-primary-foreground p-7 shadow-soft relative overflow-hidden">
            <div className="absolute -top-3 right-4 px-3 py-1 rounded-full bg-white text-primary text-xs font-bold shadow">LIMITED OFFER</div>
            <h3 className="text-lg font-bold flex items-center gap-2"><Sparkles className="h-5 w-5" />Premium+</h3>
            <p className="text-sm text-white/85 mt-1">The Ultimate Growth Engine for Your Auto Business.</p>
            <div className="mt-5 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold">$25.65</span>
              <span className="text-white/80">/month</span>
            </div>
            <div className="text-xs text-white/70 line-through">normally $299.45/mo</div>
            <ul className="mt-5 space-y-2 text-sm">
              {[
                "Unlimited Custom AI Videos",
                "High-Quality Ad Creation for vehicles & parts",
                "Unlimited edits & revisions",
                "Premium Priority Listings (top placement)",
                "Personal social media features",
              ].map((f) => (
                <li key={f} className="flex gap-2"><Check className="h-4 w-4 mt-0.5" />{f}</li>
              ))}
            </ul>
            <Link to="/checkout/$tier" params={{ tier: "premium_plus" }} className="mt-6 block text-center rounded-lg bg-white text-primary px-5 py-3 text-sm font-bold hover:bg-white/95">
              Lock In $25.65
            </Link>
          </div>
        </div>

        {/* Premium+ pitch */}
        <div className="mt-14 rounded-2xl bg-card border border-border p-8 md:p-10 shadow-card max-w-4xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-extrabold">Introducing Premium+: The Ultimate Growth Engine for Your Auto Business.</h2>
          <p className="mt-4 text-muted-foreground">
            Here is exactly what you get: <strong>Unlimited Custom AI Videos</strong> to dominate your market,
            <strong> High-Quality Ad Creation</strong> tailored specifically for vehicles and auto parts,
            <strong> Unlimited Edits</strong>, and <strong>Premium Priority Listings</strong> so your inventory gets seen first.
          </p>
          <p className="mt-4 text-muted-foreground">
            Normally, access to this powerhouse of marketing tools would cost you <strong>$299.45 per month</strong>.
            But because I'm looking to partner with serious players, I'm slashing that price.
          </p>
          <p className="mt-4 text-foreground font-semibold">
            Today, you can lock in Premium+ for just <span className="text-primary">$25.65</span>.
          </p>
          <p className="mt-3 text-muted-foreground italic">
            This isn't just a subscription; it's an unfair advantage. Grab it now.
          </p>
        </div>

        {/* Payment */}
        <div id="payment" className="mt-14 rounded-2xl bg-card border border-border p-8 shadow-card max-w-4xl mx-auto">
          <h2 className="text-2xl font-extrabold">How to pay</h2>
          <p className="text-muted-foreground mt-1">Choose your method, then send proof of payment to confirm activation.</p>
          <div className="grid sm:grid-cols-3 gap-4 mt-6">
            {[
              { icon: Building2, title: "Bank Transfer", desc: "Local Jamaican bank transfer accepted." },
              { icon: CreditCard, title: "Direct Debit / Deposit", desc: "Deposit into our account at any branch." },
              { icon: Wallet, title: "PayPal", desc: "Pay to passardmediaja@gmail.com." },
            ].map((p) => (
              <div key={p.title} className="rounded-xl border border-border p-5 bg-secondary/40">
                <p.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-3 font-semibold">{p.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">{p.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={`https://wa.me/18768598983?text=${encodeURIComponent("Hi Passard, I want to sign up for Premium/Premium+.")}`}
              target="_blank" rel="noreferrer"
              className="inline-flex items-center rounded-lg bg-[oklch(0.65_0.18_150)] text-white px-5 py-3 text-sm font-semibold hover:opacity-95"
            >
              Send payment proof on WhatsApp
            </a>
            <a href="mailto:passardmediaja@gmail.com" className="inline-flex items-center rounded-lg border border-input px-5 py-3 text-sm font-semibold hover:bg-secondary">
              Email passardmediaja@gmail.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
