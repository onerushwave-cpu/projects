import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact PassardAutoMediaJa" },
      { name: "description", content: "Reach PassardAutoMediaJa by WhatsApp or email — for listings, Premium boosts, or partnerships." },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <h1 className="text-4xl font-extrabold">Get in touch</h1>
      <p className="text-muted-foreground mt-2">We typically respond within a few hours on WhatsApp.</p>

      <div className="grid sm:grid-cols-2 gap-4 mt-8">
        <a href="https://wa.me/18768598983" target="_blank" rel="noreferrer"
          className="rounded-2xl bg-card border border-border p-6 shadow-card hover:shadow-soft transition-shadow flex gap-4">
          <div className="grid h-12 w-12 place-items-center rounded-lg bg-[oklch(0.65_0.18_150)] text-white">
            <MessageCircle className="h-6 w-6" />
          </div>
          <div>
            <div className="font-semibold">WhatsApp</div>
            <div className="text-sm text-muted-foreground">+1 (876) 859-8983</div>
            <div className="text-xs text-primary mt-1">Tap to chat →</div>
          </div>
        </a>

        <a href="mailto:passardmediaja@gmail.com"
          className="rounded-2xl bg-card border border-border p-6 shadow-card hover:shadow-soft transition-shadow flex gap-4">
          <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Mail className="h-6 w-6" />
          </div>
          <div>
            <div className="font-semibold">Email</div>
            <div className="text-sm text-muted-foreground">passardmediaja@gmail.com</div>
            <div className="text-xs text-primary mt-1">Send a message →</div>
          </div>
        </a>
      </div>

      <div className="mt-10 rounded-2xl bg-sky-soft border border-border p-6">
        <div className="flex items-start gap-3">
          <Phone className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <div className="font-semibold">Office hours</div>
            <p className="text-sm text-muted-foreground">Monday – Saturday · 9:00am – 7:00pm (JA)</p>
          </div>
        </div>
      </div>
    </div>
  );
}
