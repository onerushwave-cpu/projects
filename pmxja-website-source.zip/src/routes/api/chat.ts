import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const SYSTEM = `You are the friendly AI concierge for PassardAutoMediaJa, a Jamaican site that advertises cars and auto parts. 
- Help users find vehicles or parts, explain Free advertising, Premium (USD 10.55 — personal review on Passard's socials), and Premium+ (USD 25.65, normally USD 299.45 — unlimited custom AI videos, high-quality ad creation, unlimited edits, premium priority listings).
- For deals, hand-off, or specific seller questions, ALWAYS tell the user to tap the green "Chat seller on WhatsApp" button or message PassardAutoMediaJa directly at +1 (876) 859-8983.
- Email: passardmediaja@gmail.com.
- Be concise, warm, and helpful. Use short paragraphs.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages } = (await request.json()) as { messages: UIMessage[] };
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-2.5-flash"),
          system: SYSTEM,
          messages: await convertToModelMessages(messages),
        });
        return result.toUIMessageStreamResponse({ originalMessages: messages });
      },
    },
  },
});
