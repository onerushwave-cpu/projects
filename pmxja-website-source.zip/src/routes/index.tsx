import { createFileRoute, Link } from "@tanstack/react-router";
import { Car, Wrench, Sparkles, ShieldCheck, MessageCircle, Camera, Crown, Box } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PassardAutoMediaJa — Free Car & Parts Ads in Jamaica" },
      { name: "description", content: "Post your vehicle or auto parts for free. Upload photos, reach buyers across Jamaica, and unlock Premium AI-powered ads." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-hero text-primary-foreground">
        <div className="absolute inset-0 opacity-20" style={{ background: "radial-gradient(circle at 20% 10%, white, transparent 40%), radial-gradient(circle at 80% 70%, white, transparent 35%)" }} />
        <div className="relative mx-auto max-w-7xl px-4 py-20 md:py-28">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-medium backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" /> Free advertising for car dealers
            </div>
            <h1 className="mt-5 text-4xl md:text-6xl font-extrabold leading-[1.05]">
              Sell your car or parts <span className="text-sky-200">faster</span> in Jamaica.
            </h1>
            <p className="mt-5 text-lg text-white/90 max-w-xl">
              Upload photos, get instant exposure, and chat with buyers on WhatsApp. Free for everyone — with optional Premium boosts for serious sellers.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/sell" className="inline-flex items-center gap-2 rounded-lg bg-white px-5 py-3 text-sm font-semibold text-primary shadow-soft hover:bg-white/95">
                <Camera className="h-4 w-4" /> Post Free Ad
              </Link>
              <Link to="/browse" className="inline-flex items-center gap-2 rounded-lg bg-white/10 border border-white/30 px-5 py-3 text-sm font-semibold text-white backdrop-blur hover:bg-white/20">
                Browse Listings
              </Link>
              <Link to="/viewer" className="inline-flex items-center gap-2 rounded-lg bg-accent text-accent-foreground px-5 py-3 text-sm font-semibold hover:opacity-90">
                <Box className="h-4 w-4" /> Try the 3D Showroom
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-5 md:grid-cols-3">
          {[
            { icon: Car, title: "Free Car Ads", desc: "Dealers and private owners post unlimited cars with photos, completely free." },
            { icon: Wrench, title: "Auto Parts Marketplace", desc: "Upload pictures of your parts and reach mechanics and buyers island-wide." },
            { icon: MessageCircle, title: "AI Concierge → WhatsApp", desc: "Our chatbot answers questions and connects buyers directly to the seller on WhatsApp." },
            { icon: Box, title: "3D Showroom", desc: "Turn multi-angle photos into a 360° spin with a true 3D interior view." },
            { icon: Crown, title: "Premium Reviews", desc: "Get a personal video review on Passard's socials for just USD 10.55." },
            { icon: ShieldCheck, title: "Trusted & Local", desc: "Built in Jamaica, designed for Jamaican buyers and sellers." },
          ].map((f, i) => (
            <div key={i} className="rounded-xl bg-card border border-border p-6 shadow-card hover:shadow-soft transition-shadow">
              <div className="grid h-11 w-11 place-items-center rounded-lg bg-secondary text-primary">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Premium CTA */}
      <section className="bg-sky-soft">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <div className="rounded-2xl bg-card border border-border p-8 md:p-12 shadow-card grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-semibold">
                <Crown className="h-3.5 w-3.5" /> Introducing Premium+
              </div>
              <h2 className="mt-4 text-3xl md:text-4xl font-extrabold">The Ultimate Growth Engine for Your Auto Business.</h2>
              <p className="mt-4 text-muted-foreground">
                Unlimited Custom AI Videos, High-Quality Ad Creation for vehicles & parts, unlimited edits, and Premium Priority Listings — so your inventory gets seen first.
              </p>
              <div className="mt-6 flex items-baseline gap-3">
                <span className="text-muted-foreground line-through">USD 299.45/mo</span>
                <span className="text-3xl font-extrabold text-primary">USD 25.65</span>
                <span className="text-sm text-muted-foreground">/month — limited slots</span>
              </div>
              <Link to="/pricing" className="mt-6 inline-flex items-center rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-soft hover:bg-primary/90">
                Lock In Premium+
              </Link>
            </div>
            <ul className="space-y-3 text-sm">
              {[
                "Unlimited Custom AI Videos",
                "High-Quality Ad Creation for vehicles & auto parts",
                "Unlimited edits & revisions",
                "Premium priority listings (top placement)",
                "Personal social media features",
                "WhatsApp lead routing",
              ].map((b) => (
                <li key={b} className="flex items-start gap-3 rounded-lg bg-secondary/60 px-4 py-3">
                  <span className="mt-0.5 grid h-5 w-5 place-items-center rounded-full bg-primary text-primary-foreground text-xs">✓</span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
