import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ThreeSixtyViewer } from "@/components/ThreeSixtyViewer";
import { Interior3D } from "@/components/Interior3D";
import { Upload, X, Sparkles } from "lucide-react";

export const Route = createFileRoute("/viewer")({
  head: () => ({
    meta: [
      { title: "3D Vehicle Showroom — PassardAutoMediaJa" },
      { name: "description", content: "Upload multiple photos of your vehicle and explore a 360° exterior plus interactive 3D interior with door, dashboard and rear cabin views." },
    ],
  }),
  component: Viewer,
});

function fileToDataUrl(f: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result as string);
    r.onerror = rej;
    r.readAsDataURL(f);
  });
}

function Viewer() {
  const [images, setImages] = useState<string[]>([]);

  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    const arr = await Promise.all(Array.from(files).slice(0, 36).map(fileToDataUrl));
    setImages((p) => [...p, ...arr].slice(0, 36));
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-semibold">
          <Sparkles className="h-3.5 w-3.5" /> Photorealistic 3D Showroom
        </div>
        <h1 className="mt-4 text-4xl font-extrabold">Bring your listing to life</h1>
        <p className="mt-3 text-muted-foreground">
          Upload multiple reference photos around your car. We stitch them into a smooth 360° spin you can drag and zoom — and pair it with an interactive 3D interior you can explore.
        </p>
      </div>

      {/* Upload */}
      <div className="mt-8 rounded-2xl bg-card border border-border p-6 shadow-card">
        <label className="block rounded-xl border-2 border-dashed border-border hover:border-primary/60 transition-colors cursor-pointer bg-sky-soft p-8 text-center">
          <Upload className="mx-auto h-8 w-8 text-primary" />
          <div className="mt-2 text-sm font-medium">Upload multiple reference images</div>
          <div className="text-xs text-muted-foreground">For best results, take 12–24 photos walking around the car.</div>
          <input type="file" multiple accept="image/*" className="hidden" onChange={(e) => onFiles(e.target.files)} />
        </label>
        {images.length > 0 && (
          <>
            <div className="mt-3 grid grid-cols-6 sm:grid-cols-8 gap-2">
              {images.map((src, i) => (
                <div key={i} className="relative aspect-square rounded-md overflow-hidden border border-border">
                  <img src={src} alt={`ref ${i}`} className="w-full h-full object-cover" />
                  <button type="button" onClick={() => setImages((p) => p.filter((_, j) => j !== i))}
                    className="absolute top-0.5 right-0.5 grid h-5 w-5 place-items-center rounded-full bg-black/70 text-white">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {images.length} reference image{images.length === 1 ? "" : "s"} loaded.
            </p>
          </>
        )}
      </div>

      {/* Viewers */}
      <div className="grid lg:grid-cols-2 gap-6 mt-8">
        <div>
          <h2 className="text-lg font-bold mb-3">360° Exterior (from your photos)</h2>
          <ThreeSixtyViewer images={images} />
          <p className="text-xs text-muted-foreground mt-2">Drag the image left/right to rotate around the vehicle.</p>
        </div>
        <div>
          <h2 className="text-lg font-bold mb-3">Interactive 3D Interior</h2>
          <Interior3D />
          <p className="text-xs text-muted-foreground mt-2">
            Tap the doors to enter, then switch between front cabin (dashboard, steering wheel, shifter, seats) and rear cabin.
          </p>
        </div>
      </div>
    </div>
  );
}
