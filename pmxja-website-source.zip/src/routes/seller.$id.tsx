import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getSellerListings } from "@/lib/listings.functions";
import { BadgeCheck, MapPin, Phone, Car, Wrench } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/seller/$id")({
  parseParams: (p) => ({ id: z.string().uuid().parse(p.id) }),
  head: ({ params }) => ({
    meta: [{ title: `Seller — PassardAutoMediaJa` }],
  }),
  component: Seller,
});

function Seller() {
  const { id } = Route.useParams();
  const fetchFn = useServerFn(getSellerListings);
  const { data } = useQuery({ queryKey: ["seller", id], queryFn: () => fetchFn({ data: { id } }) });
  const [avatar, setAvatar] = useState<string | null>(null);

  useEffect(() => {
    if (data?.profile?.avatar_url) {
      supabase.storage.from("avatars").createSignedUrl(data.profile.avatar_url, 3600).then((r) => {
        setAvatar(r.data?.signedUrl ?? null);
      });
    }
  }, [data]);

  if (!data) return <div className="mx-auto max-w-5xl px-4 py-10">Loading…</div>;
  const { profile, listings } = data;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="rounded-2xl bg-card border border-border p-6 shadow-card flex flex-col sm:flex-row gap-6 items-start">
        <div className="h-24 w-24 rounded-full overflow-hidden bg-secondary grid place-items-center text-2xl font-bold text-muted-foreground">
          {avatar ? (
            <img src={avatar} className="w-full h-full object-cover" alt="" />
          ) : (
            (profile?.display_name?.[0] ?? "?").toUpperCase()
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-extrabold">
              {profile?.dealership_name || profile?.display_name || "Seller"}
            </h1>
            {profile?.verified && (
              <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">
                <BadgeCheck className="h-3 w-3" /> Verified
              </span>
            )}
          </div>
          {profile?.location && (
            <p className="text-sm text-muted-foreground mt-1 inline-flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" /> {profile.location}
            </p>
          )}
          {profile?.bio && <p className="text-sm mt-3">{profile.bio}</p>}
          {profile?.whatsapp && (
            <a
              href={`https://wa.me/${profile.whatsapp.replace(/\D/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-[oklch(0.65_0.18_150)] text-white px-4 py-2 text-sm font-semibold"
            >
              <Phone className="h-4 w-4" /> Chat on WhatsApp
            </a>
          )}
        </div>
      </div>

      <h2 className="text-xl font-bold mt-10 mb-4">Active listings</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {listings.length === 0 && (
          <p className="text-sm text-muted-foreground col-span-full">No active listings.</p>
        )}
        {listings.map((l) => (
          <div key={l.id} className="rounded-xl bg-card border border-border overflow-hidden shadow-card">
            <div className="aspect-video bg-sky-soft">
              {l.image_urls?.[0] ? (
                <img src={l.image_urls[0]} alt={l.title} className="w-full h-full object-cover" />
              ) : (
                <div className="grid place-items-center h-full text-primary/40">
                  {l.kind === "car" ? <Car className="h-12 w-12" /> : <Wrench className="h-12 w-12" />}
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="font-semibold text-sm line-clamp-1">{l.title}</h3>
              <p className="text-primary font-bold text-sm mt-0.5">{l.price}</p>
            </div>
          </div>
        ))}
      </div>
      <Link to="/browse" className="inline-block mt-6 text-sm text-primary hover:underline">
        ← Back to all listings
      </Link>
    </div>
  );
}
