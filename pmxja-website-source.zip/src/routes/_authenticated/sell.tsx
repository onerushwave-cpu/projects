import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { uploadFile } from "@/lib/storage";
import { createListing } from "@/lib/listings.functions";
import { Upload, X, Check, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/sell")({
  head: () => ({
    meta: [
      { title: "Post a Free Ad — PassardAutoMediaJa" },
      { name: "description", content: "Free car & auto parts advertising in Jamaica. Upload multiple photos and reach island-wide buyers." },
    ],
  }),
  component: Sell,
});

function Sell() {
  const nav = useNavigate();
  const create = useServerFn(createListing);
  const [userId, setUserId] = useState<string | null>(null);
  const [kind, setKind] = useState<"car" | "part">("car");
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [year, setYear] = useState("");
  const [make, setMake] = useState("");
  const [model, setModel] = useState("");
  const [mileage, setMileage] = useState("");
  const [condition, setCondition] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const onFiles = (fl: FileList | null) => {
    if (!fl) return;
    const arr = Array.from(fl).slice(0, 12);
    setFiles((p) => [...p, ...arr].slice(0, 12));
    setPreviews((p) => [...p, ...arr.map((f) => URL.createObjectURL(f))].slice(0, 12));
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!userId) return;
    if (files.length === 0) {
      setErr("Please upload at least one photo.");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const paths: string[] = [];
      for (const f of files) {
        const p = await uploadFile("listing-images", userId, f);
        paths.push(p);
      }
      await create({
        data: {
          kind,
          title,
          description,
          price,
          location,
          year: year ? Number(year) : null,
          make: make || null,
          model: model || null,
          mileage: mileage || null,
          condition: condition || null,
          images: paths,
        },
      });
      setDone(true);
      setTimeout(() => nav({ to: "/dashboard" }), 1500);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to publish");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16">
        <div className="rounded-2xl bg-secondary border border-border p-10 text-center">
          <div className="mx-auto h-14 w-14 grid place-items-center rounded-full bg-primary text-primary-foreground">
            <Check className="h-7 w-7" />
          </div>
          <h2 className="mt-4 text-2xl font-bold">Listing submitted!</h2>
          <p className="text-muted-foreground text-sm mt-2">
            Your ad is now in the moderation queue. Once approved (usually within a few hours),
            it will appear on the Browse page.
          </p>
          <p className="text-xs text-muted-foreground mt-3">Redirecting to your dashboard…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Post a Free Ad</h1>
      <p className="text-muted-foreground mt-1">
        Upload photos of your vehicle or auto parts. Always free — and reviewed within a few hours before going live.
      </p>

      <form onSubmit={submit} className="mt-8 space-y-5 rounded-2xl bg-card border border-border p-6 shadow-card">
        <div className="flex gap-2">
          {(["car", "part"] as const).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setKind(k)}
              className={`flex-1 rounded-lg px-4 py-3 text-sm font-semibold border-2 transition-colors ${
                kind === k
                  ? "border-primary bg-primary/5 text-primary"
                  : "border-border text-muted-foreground hover:border-primary/50"
              }`}
            >
              {k === "car" ? "🚗 Vehicle" : "🔧 Auto Part"}
            </button>
          ))}
        </div>

        <Field label="Title" value={title} onChange={setTitle} placeholder="2018 Honda Fit — One owner" required maxLength={120} />
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Price" value={price} onChange={setPrice} placeholder="USD 9,500" required />
          <Field label="Location" value={location} onChange={setLocation} placeholder="Kingston, JA" required />
        </div>

        {kind === "car" && (
          <div className="grid sm:grid-cols-3 gap-4">
            <Field label="Year" value={year} onChange={setYear} placeholder="2019" type="number" />
            <Field label="Make" value={make} onChange={setMake} placeholder="Toyota" />
            <Field label="Model" value={model} onChange={setModel} placeholder="Axio" />
            <Field label="Mileage" value={mileage} onChange={setMileage} placeholder="68,000 km" />
            <Field label="Condition" value={condition} onChange={setCondition} placeholder="Excellent" />
          </div>
        )}

        <div>
          <Label>Description</Label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            required
            minLength={10}
            maxLength={2000}
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <Label>Photos (up to 12)</Label>
          <label className="block rounded-xl border-2 border-dashed border-border hover:border-primary/60 transition-colors cursor-pointer bg-sky-soft p-8 text-center">
            <Upload className="mx-auto h-8 w-8 text-primary" />
            <div className="mt-2 text-sm font-medium">Click to upload images</div>
            <div className="text-xs text-muted-foreground">JPG/PNG · multi-select supported</div>
            <input type="file" multiple accept="image/*" className="hidden" onChange={(e) => onFiles(e.target.files)} />
          </label>
          {previews.length > 0 && (
            <div className="mt-3 grid grid-cols-4 gap-2">
              {previews.map((src, i) => (
                <div key={i} className="relative aspect-square rounded-md overflow-hidden border border-border">
                  <img src={src} alt={`upload ${i}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => {
                      setPreviews((p) => p.filter((_, j) => j !== i));
                      setFiles((p) => p.filter((_, j) => j !== i));
                    }}
                    className="absolute top-1 right-1 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {err && (
          <div className="flex items-start gap-2 rounded-md bg-destructive/10 text-destructive text-sm px-3 py-2">
            <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
          </div>
        )}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-lg bg-primary text-primary-foreground px-5 py-3 font-semibold shadow-soft hover:bg-primary/90 disabled:opacity-60"
        >
          {busy ? "Uploading…" : "Submit for review"}
        </button>

        <p className="text-xs text-muted-foreground text-center">
          Want priority placement? After submitting, upgrade this listing to{" "}
          <Link to="/pricing" className="text-primary font-medium">Premium</Link>.
        </p>
      </form>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <div className="text-sm font-medium mb-1.5">{children}</div>;
}
function Field({
  label, value, onChange, ...rest
}: {
  label: string; value: string; onChange: (v: string) => void;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) {
  return (
    <div>
      <Label>{label}</Label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        {...rest}
        className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}
