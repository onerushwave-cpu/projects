import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  adminListListings,
  adminModerateListing,
  adminListPayments,
  adminReviewPayment,
  adminGetSignedProofUrl,
} from "@/lib/admin.functions";
import { TIER_LABEL } from "@/lib/db-types";
import { Check, X, ExternalLink, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — PassardAutoMediaJa" }] }),
  component: Admin,
});

function Admin() {
  const [tab, setTab] = useState<"listings" | "payments">("listings");
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-extrabold flex items-center gap-2">
        <ShieldCheck className="h-7 w-7 text-primary" /> Admin moderation
      </h1>
      <p className="text-muted-foreground text-sm mt-1">Review listings and verify payments.</p>

      <div className="mt-6 flex gap-1 rounded-lg bg-secondary p-1 w-fit">
        {(["listings", "payments"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-md text-sm font-medium capitalize ${
              tab === t ? "bg-card shadow-card text-primary" : "text-muted-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "listings" ? <ListingsQueue /> : <PaymentsQueue />}
    </div>
  );
}

function ListingsQueue() {
  const qc = useQueryClient();
  const fetchFn = useServerFn(adminListListings);
  const modFn = useServerFn(adminModerateListing);
  const { data } = useQuery({ queryKey: ["admin-listings"], queryFn: () => fetchFn() });
  const moderate = useMutation({
    mutationFn: (v: { id: string; action: "approve" | "reject"; reason?: string }) =>
      modFn({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-listings"] }),
  });

  return (
    <div className="mt-6 space-y-3">
      {data?.length === 0 && <p className="text-sm text-muted-foreground">No listings.</p>}
      {data?.map((l) => (
        <div key={l.id} className="rounded-xl border border-border bg-card p-4 flex flex-wrap gap-4 items-start">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full ${
                l.status === "approved" ? "bg-emerald-100 text-emerald-800"
                  : l.status === "rejected" ? "bg-red-100 text-red-800"
                  : "bg-amber-100 text-amber-800"
              }`}>{l.status}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary uppercase font-semibold">
                {TIER_LABEL[l.tier]}
              </span>
              <span className="text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString()}</span>
            </div>
            <h3 className="font-semibold mt-1">{l.title}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2">{l.description}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {l.price} · {l.location} · {l.images?.length ?? 0} photo(s)
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => moderate.mutate({ id: l.id, action: "approve" })}
              className="inline-flex items-center gap-1 rounded-md bg-emerald-600 text-white px-3 py-1.5 text-xs font-semibold"
            >
              <Check className="h-3.5 w-3.5" /> Approve
            </button>
            <button
              onClick={() => {
                const reason = prompt("Rejection reason?");
                if (reason) moderate.mutate({ id: l.id, action: "reject", reason });
              }}
              className="inline-flex items-center gap-1 rounded-md bg-red-600 text-white px-3 py-1.5 text-xs font-semibold"
            >
              <X className="h-3.5 w-3.5" /> Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

function PaymentsQueue() {
  const qc = useQueryClient();
  const fetchFn = useServerFn(adminListPayments);
  const reviewFn = useServerFn(adminReviewPayment);
  const proofFn = useServerFn(adminGetSignedProofUrl);
  const { data } = useQuery({ queryKey: ["admin-payments"], queryFn: () => fetchFn() });
  const review = useMutation({
    mutationFn: (v: { id: string; action: "verify" | "reject" }) => reviewFn({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-payments"] }),
  });

  async function viewProof(path: string) {
    const { url } = await proofFn({ data: { path } });
    window.open(url, "_blank");
  }

  return (
    <div className="mt-6 space-y-3">
      {data?.length === 0 && <p className="text-sm text-muted-foreground">No payments.</p>}
      {data?.map((p) => (
        <div key={p.id} className="rounded-xl border border-border bg-card p-4 flex flex-wrap items-center gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full ${
                p.status === "verified" ? "bg-emerald-100 text-emerald-800"
                  : p.status === "rejected" ? "bg-red-100 text-red-800"
                  : "bg-amber-100 text-amber-800"
              }`}>{p.status}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary uppercase font-semibold">
                {TIER_LABEL[p.tier]}
              </span>
              <span className="text-xs">${Number(p.amount).toFixed(2)} · {p.method.replace("_", " ")}</span>
              <span className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleString()}</span>
            </div>
            {p.provider_ref && <p className="text-xs text-muted-foreground mt-1">Ref: {p.provider_ref}</p>}
            {p.note && <p className="text-xs text-muted-foreground mt-0.5">Note: {p.note}</p>}
          </div>
          <div className="flex gap-2">
            {p.proof_url && (
              <button
                onClick={() => viewProof(p.proof_url!)}
                className="inline-flex items-center gap-1 rounded-md border border-input px-3 py-1.5 text-xs"
              >
                <ExternalLink className="h-3.5 w-3.5" /> Proof
              </button>
            )}
            <button
              onClick={() => review.mutate({ id: p.id, action: "verify" })}
              className="inline-flex items-center gap-1 rounded-md bg-emerald-600 text-white px-3 py-1.5 text-xs font-semibold"
            >
              <Check className="h-3.5 w-3.5" /> Verify
            </button>
            <button
              onClick={() => review.mutate({ id: p.id, action: "reject" })}
              className="inline-flex items-center gap-1 rounded-md bg-red-600 text-white px-3 py-1.5 text-xs font-semibold"
            >
              <X className="h-3.5 w-3.5" /> Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
