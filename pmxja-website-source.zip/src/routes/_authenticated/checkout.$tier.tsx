import { createFileRoute, useSearch, useNavigate, Link } from "@tanstack/react-router";
import { z } from "zod";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { submitPayment } from "@/lib/payments.functions";
import { uploadFile } from "@/lib/storage";
import { supabase } from "@/integrations/supabase/client";
import { TIER_PRICE, TIER_LABEL, type ListingTier, type PaymentMethod } from "@/lib/db-types";
import { Upload, CreditCard, Building2, Wallet, AlertCircle, CheckCircle2, Info } from "lucide-react";

export const Route = createFileRoute("/_authenticated/checkout/$tier")({
  validateSearch: z.object({ listing: z.string().uuid().optional() }),
  head: () => ({ meta: [{ title: "Checkout — PassardAutoMediaJa" }] }),
  component: Checkout,
});

const methods: { id: PaymentMethod; label: string; icon: any; desc: string }[] = [
  { id: "bank", label: "Bank Transfer", icon: Building2, desc: "Local Jamaican bank transfer." },
  { id: "direct_debit", label: "Direct Debit / Deposit", icon: CreditCard, desc: "Deposit at any branch." },
  { id: "paypal", label: "PayPal", icon: Wallet, desc: "Pay to passardmediaja@gmail.com." },
];

function Checkout() {
  const params = Route.useParams();
  const { listing } = useSearch({ from: "/_authenticated/checkout/$tier" });
  const nav = useNavigate();
  const submit = useServerFn(submitPayment);

  const tier = (params.tier === "premium_plus" ? "premium_plus" : "premium") as Exclude<ListingTier, "free">;
  const amount = TIER_PRICE[tier];

  const [method, setMethod] = useState<PaymentMethod>("bank");
  const [providerRef, setProviderRef] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function go(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Not signed in");
      let proofPath: string | null = null;
      if (file) proofPath = await uploadFile("payment-proofs", u.user.id, file);

      await submit({
        data: {
          listingId: listing ?? null,
          tier,
          method,
          amount,
          providerRef: providerRef || null,
          proofPath,
          note: note || null,
        },
      });
      setDone(true);
      setTimeout(() => nav({ to: "/dashboard" }), 2200);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to submit payment");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="rounded-2xl bg-secondary border border-border p-10">
          <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-600" />
          <h2 className="mt-4 text-2xl font-bold">Payment submitted!</h2>
          <p className="text-muted-foreground text-sm mt-2">
            We'll verify your payment and activate your {TIER_LABEL[tier]} listing within a few hours.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Activate {TIER_LABEL[tier]}</h1>
      <p className="text-muted-foreground text-sm mt-1">
        ${amount.toFixed(2)} {tier === "premium_plus" ? "/month" : "one-time"}.{" "}
        Pay using the method below, then upload proof to activate.
      </p>

      <div className="mt-6 rounded-xl bg-sky-soft border border-border p-4 text-sm flex gap-2">
        <Info className="h-4 w-4 mt-0.5 text-primary" />
        <div>
          <strong>Instant card payments are coming soon.</strong> For now, pay via bank / direct debit / PayPal and
          upload proof — your listing activates as soon as we verify (usually within a few hours).
        </div>
      </div>

      <form onSubmit={go} className="mt-6 space-y-5 rounded-2xl bg-card border border-border p-6 shadow-card">
        <div>
          <div className="text-sm font-medium mb-2">Payment method</div>
          <div className="grid sm:grid-cols-3 gap-2">
            {methods.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={`rounded-lg border-2 p-3 text-left ${
                  method === m.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
              >
                <m.icon className="h-5 w-5 text-primary" />
                <div className="mt-1 text-sm font-semibold">{m.label}</div>
                <div className="text-[11px] text-muted-foreground">{m.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-lg bg-secondary/40 border border-border p-4 text-sm">
          <p className="font-semibold mb-1">Where to send the money:</p>
          <ul className="text-muted-foreground space-y-0.5 text-xs">
            <li>• Bank transfer / deposit: contact PassardAutoMediaJa on WhatsApp for bank details.</li>
            <li>• PayPal: passardmediaja@gmail.com</li>
            <li>• Reference your username or listing title so we can match it.</li>
          </ul>
          <a
            href={`https://wa.me/18768598983?text=${encodeURIComponent(`Hi, I want to pay for ${TIER_LABEL[tier]} (USD ${amount.toFixed(2)}). Please send bank details.`)}`}
            target="_blank"
            rel="noreferrer"
            className="inline-block mt-2 text-xs text-primary font-medium hover:underline"
          >
            → Request bank details on WhatsApp
          </a>
        </div>

        <label className="block">
          <div className="text-sm font-medium mb-1.5">Transaction reference / receipt #</div>
          <input
            value={providerRef}
            onChange={(e) => setProviderRef(e.target.value)}
            placeholder="e.g. NCB-TX-19283"
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </label>

        <label className="block">
          <div className="text-sm font-medium mb-1.5">Note (optional)</div>
          <textarea
            rows={2}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </label>

        <div>
          <div className="text-sm font-medium mb-1.5">Upload proof of payment (screenshot / receipt)</div>
          <label className="block rounded-xl border-2 border-dashed border-border hover:border-primary/60 transition-colors cursor-pointer bg-sky-soft p-6 text-center">
            <Upload className="mx-auto h-6 w-6 text-primary" />
            <div className="mt-1 text-sm font-medium">
              {file ? file.name : "Click to upload proof"}
            </div>
            <div className="text-xs text-muted-foreground">PDF or image</div>
            <input
              type="file"
              accept="image/*,application/pdf"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>
        </div>

        {err && (
          <div className="flex items-start gap-2 rounded-md bg-destructive/10 text-destructive text-sm px-3 py-2">
            <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
          </div>
        )}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-lg bg-primary text-primary-foreground px-5 py-3 font-semibold shadow-soft hover:bg-primary/90 disabled:opacity-60"
        >
          {busy ? "Submitting…" : `Submit ${TIER_LABEL[tier]} payment for review`}
        </button>
      </form>
    </div>
  );
}
