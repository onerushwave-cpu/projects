import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getMyListings, deleteMyListing, generatePromoVideo } from "@/lib/listings.functions";
import { getMyPayments } from "@/lib/payments.functions";
import { getMyProfile, updateMyProfile } from "@/lib/profile.functions";
import { TIER_LABEL } from "@/lib/db-types";
import {
  Crown, Sparkles, Trash2, Clock, CheckCircle, XCircle, Wand2, Camera, Loader2,
} from "lucide-react";
import { uploadFile } from "@/lib/storage";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "My Dashboard — PassardAutoMediaJa" }] }),
  component: Dashboard,
});

function StatusPill({ s }: { s: string }) {
  const map: Record<string, { c: string; i: any; t: string }> = {
    pending: { c: "bg-amber-100 text-amber-800", i: Clock, t: "Pending review" },
    approved: { c: "bg-emerald-100 text-emerald-800", i: CheckCircle, t: "Approved" },
    rejected: { c: "bg-red-100 text-red-800", i: XCircle, t: "Rejected" },
    sold: { c: "bg-slate-200 text-slate-700", i: CheckCircle, t: "Sold" },
  };
  const m = map[s] ?? map.pending;
  const I = m.i;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${m.c}`}>
      <I className="h-3 w-3" /> {m.t}
    </span>
  );
}

function TierPill({ tier }: { tier: string }) {
  if (tier === "free") return null;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${
        tier === "premium_plus"
          ? "bg-gradient-to-r from-primary to-accent text-primary-foreground"
          : "bg-primary/15 text-primary"
      }`}
    >
      {tier === "premium_plus" ? <Sparkles className="h-3 w-3" /> : <Crown className="h-3 w-3" />}
      {TIER_LABEL[tier as keyof typeof TIER_LABEL]}
    </span>
  );
}

function Dashboard() {
  const qc = useQueryClient();
  const fetchListings = useServerFn(getMyListings);
  const fetchPayments = useServerFn(getMyPayments);
  const fetchProfile = useServerFn(getMyProfile);
  const delFn = useServerFn(deleteMyListing);
  const promoFn = useServerFn(generatePromoVideo);
  const saveProfile = useServerFn(updateMyProfile);

  const { data: listings } = useQuery({ queryKey: ["my-listings"], queryFn: () => fetchListings() });
  const { data: payments } = useQuery({ queryKey: ["my-payments"], queryFn: () => fetchPayments() });
  const { data: profile } = useQuery({ queryKey: ["my-profile"], queryFn: () => fetchProfile() });

  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-listings"] }),
  });
  const promo = useMutation({
    mutationFn: (listingId: string) => promoFn({ data: { listingId } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-listings"] }),
  });

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 space-y-10">
      <h1 className="text-3xl font-extrabold">My Dashboard</h1>

      <ProfileCard
        profile={profile ?? null}
        onSave={async (patch) => {
          await saveProfile({ data: patch });
          qc.invalidateQueries({ queryKey: ["my-profile"] });
        }}
      />

      <section>
        <div className="flex items-end justify-between mb-4">
          <h2 className="text-xl font-bold">My listings</h2>
          <Link to="/sell" className="rounded-md bg-primary text-primary-foreground px-3 py-1.5 text-sm font-semibold">
            + New ad
          </Link>
        </div>
        {!listings?.length ? (
          <p className="text-sm text-muted-foreground rounded-xl border border-dashed border-border p-8 text-center">
            You haven't posted any listings yet.
          </p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {listings.map((l) => (
              <div key={l.id} className="rounded-xl bg-card border border-border overflow-hidden shadow-card">
                <div className="aspect-video bg-sky-soft relative">
                  {l.image_urls?.[0] ? (
                    <img src={l.image_urls[0]} alt={l.title} className="w-full h-full object-cover" />
                  ) : null}
                  <div className="absolute top-2 left-2 flex gap-1.5">
                    <StatusPill s={l.status} />
                    <TierPill tier={l.tier} />
                  </div>
                </div>
                <div className="p-4 space-y-2">
                  <h3 className="font-semibold leading-tight line-clamp-1">{l.title}</h3>
                  <div className="text-primary font-bold text-sm">{l.price}</div>
                  {l.status === "rejected" && l.rejection_reason && (
                    <div className="text-xs rounded-md bg-red-50 text-red-700 px-2 py-1.5">
                      Rejected: {l.rejection_reason}
                    </div>
                  )}
                  <div className="flex gap-2 pt-1">
                    {l.tier !== "free" ? null : (
                      <Link
                        to="/checkout/$tier"
                        params={{ tier: "premium" }}
                        search={{ listing: l.id }}
                        className="text-xs rounded-md border border-primary/30 text-primary px-2 py-1 hover:bg-primary/5"
                      >
                        Upgrade
                      </Link>
                    )}
                    {l.tier === "premium_plus" && (
                      <button
                        disabled={promo.isPending}
                        onClick={() => promo.mutate(l.id)}
                        className="text-xs inline-flex items-center gap-1 rounded-md bg-gradient-to-r from-primary to-accent text-primary-foreground px-2 py-1 disabled:opacity-50"
                      >
                        {promo.isPending && promo.variables === l.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Wand2 className="h-3 w-3" />
                        )}
                        AI Promo
                      </button>
                    )}
                    <button
                      onClick={() => confirm("Delete this listing?") && del.mutate(l.id)}
                      className="ml-auto text-xs inline-flex items-center gap-1 rounded-md text-red-600 hover:bg-red-50 px-2 py-1"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">My payments</h2>
        {!payments?.length ? (
          <p className="text-sm text-muted-foreground rounded-xl border border-dashed border-border p-8 text-center">
            No payments yet. Upgrade a listing from Pricing to get started.
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-3 py-2">Date</th>
                  <th className="px-3 py-2">Tier</th>
                  <th className="px-3 py-2">Amount</th>
                  <th className="px-3 py-2">Method</th>
                  <th className="px-3 py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-t border-border">
                    <td className="px-3 py-2">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="px-3 py-2">{TIER_LABEL[p.tier]}</td>
                    <td className="px-3 py-2">${Number(p.amount).toFixed(2)}</td>
                    <td className="px-3 py-2 capitalize">{p.method.replace("_", " ")}</td>
                    <td className="px-3 py-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        p.status === "verified" ? "bg-emerald-100 text-emerald-800"
                          : p.status === "rejected" ? "bg-red-100 text-red-800"
                          : "bg-amber-100 text-amber-800"
                      }`}>{p.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

function ProfileCard({
  profile, onSave,
}: { profile: any; onSave: (patch: any) => Promise<void> }) {
  const [form, setForm] = useState<any>(null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setForm({
        display_name: profile.display_name ?? "",
        dealership_name: profile.dealership_name ?? "",
        phone: profile.phone ?? "",
        whatsapp: profile.whatsapp ?? "",
        bio: profile.bio ?? "",
        location: profile.location ?? "",
      });
      if (profile.avatar_url) {
        supabase.storage.from("avatars").createSignedUrl(profile.avatar_url, 3600).then((r) => {
          setAvatarUrl(r.data?.signedUrl ?? null);
        });
      }
    }
  }, [profile]);

  if (!form) return null;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const patch: any = { ...form };
      if (avatarFile) {
        const { data: userData } = await supabase.auth.getUser();
        if (userData.user) {
          const path = await uploadFile("avatars", userData.user.id, avatarFile);
          patch.avatar_url = path;
        }
      }
      await onSave(patch);
      setAvatarFile(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={save} className="rounded-2xl bg-card border border-border p-6 shadow-card">
      <h2 className="text-xl font-bold mb-4">Seller profile</h2>
      <div className="flex flex-col sm:flex-row gap-6">
        <div className="flex flex-col items-center gap-2">
          <div className="h-24 w-24 rounded-full bg-secondary overflow-hidden grid place-items-center">
            {avatarFile ? (
              <img src={URL.createObjectURL(avatarFile)} className="w-full h-full object-cover" />
            ) : avatarUrl ? (
              <img src={avatarUrl} className="w-full h-full object-cover" />
            ) : (
              <Camera className="h-8 w-8 text-muted-foreground" />
            )}
          </div>
          <label className="text-xs text-primary cursor-pointer">
            Change photo
            <input type="file" accept="image/*" className="hidden" onChange={(e) => setAvatarFile(e.target.files?.[0] ?? null)} />
          </label>
        </div>

        <div className="flex-1 grid sm:grid-cols-2 gap-3">
          {[
            ["display_name", "Display name"],
            ["dealership_name", "Dealership name"],
            ["phone", "Phone"],
            ["whatsapp", "WhatsApp (e.g. 18768598983)"],
            ["location", "Location"],
          ].map(([k, label]) => (
            <label key={k} className="text-sm">
              <div className="font-medium mb-1">{label}</div>
              <input
                value={form[k] ?? ""}
                onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
            </label>
          ))}
          <label className="text-sm sm:col-span-2">
            <div className="font-medium mb-1">Bio</div>
            <textarea
              rows={2}
              value={form.bio ?? ""}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </label>
        </div>
      </div>
      <div className="mt-4 flex justify-end">
        <button
          type="submit"
          disabled={busy}
          className="rounded-lg bg-primary text-primary-foreground px-5 py-2 text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
        >
          {busy ? "Saving…" : "Save profile"}
        </button>
      </div>
    </form>
  );
}
