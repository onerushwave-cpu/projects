import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { DbPayment } from "./db-types";

function publicClient() {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

const SubmitInput = z.object({
  listingId: z.string().uuid().nullable(),
  tier: z.enum(["premium", "premium_plus"]),
  method: z.enum(["stripe", "bank", "paypal", "direct_debit"]),
  amount: z.number().positive(),
  providerRef: z.string().max(200).nullable(),
  proofPath: z.string().max(400).nullable(), // storage path in payment-proofs
  note: z.string().max(500).nullable(),
});

export const submitPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SubmitInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("payments")
      .insert({
        user_id: context.userId,
        listing_id: data.listingId,
        tier: data.tier,
        amount: data.amount,
        method: data.method,
        provider_ref: data.providerRef,
        proof_url: data.proofPath,
        note: data.note,
        status: "pending",
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id as string };
  });

export const getMyPayments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("payments")
      .select("*")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as unknown as DbPayment[];
  });
