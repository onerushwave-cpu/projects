import { supabase } from "@/integrations/supabase/client";

export async function signListingImages(paths: string[]): Promise<string[]> {
  if (!paths.length) return [];
  const { data } = await supabase.storage.from("listing-images").createSignedUrls(paths, 60 * 60);
  return (data ?? []).map((d) => d.signedUrl ?? "").filter(Boolean);
}

export async function signAvatar(path: string | null): Promise<string | null> {
  if (!path) return null;
  const { data } = await supabase.storage.from("avatars").createSignedUrl(path, 60 * 60);
  return data?.signedUrl ?? null;
}

export async function uploadFile(
  bucket: "listing-images" | "avatars" | "payment-proofs",
  userId: string,
  file: File,
): Promise<string> {
  const ext = file.name.split(".").pop() ?? "bin";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
  });
  if (error) throw error;
  return path;
}
