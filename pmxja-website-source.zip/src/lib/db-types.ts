export type ListingKind = "car" | "part";
export type ListingTier = "free" | "premium" | "premium_plus";
export type ListingStatus = "pending" | "approved" | "rejected" | "sold";
export type PaymentMethod = "stripe" | "bank" | "paypal" | "direct_debit";
export type PaymentStatus = "pending" | "verified" | "rejected";

export interface DbListing {
  id: string;
  seller_id: string;
  kind: ListingKind;
  title: string;
  description: string;
  price: string;
  year: number | null;
  make: string | null;
  model: string | null;
  mileage: string | null;
  condition: string | null;
  location: string;
  images: string[]; // storage paths in listing-images bucket
  image_urls?: string[]; // signed URLs filled in by server
  tier: ListingTier;
  status: ListingStatus;
  rejection_reason: string | null;
  promo_video_url: string | null;
  views: number;
  created_at: string;
  updated_at: string;
  seller?: SellerSnippet | null;
}

export interface SellerSnippet {
  id: string;
  display_name: string | null;
  dealership_name: string | null;
  avatar_url: string | null;
  whatsapp: string | null;
  location: string | null;
  verified: boolean;
}

export interface DbProfile extends SellerSnippet {
  email: string | null;
  phone: string | null;
  bio: string | null;
  created_at: string;
}

export interface DbPayment {
  id: string;
  user_id: string;
  listing_id: string | null;
  tier: ListingTier;
  amount: number;
  method: PaymentMethod;
  provider_ref: string | null;
  proof_url: string | null;
  note: string | null;
  status: PaymentStatus;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export const TIER_LABEL: Record<ListingTier, string> = {
  free: "Free",
  premium: "Premium",
  premium_plus: "Premium+",
};

export const TIER_PRICE: Record<Exclude<ListingTier, "free">, number> = {
  premium: 10.55,
  premium_plus: 25.65,
};
