import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";
import { generateText } from "ai";
import type { DbListing, SellerSnippet } from "./db-types";

function publicClient() {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function signImages(
  sb: ReturnType<typeof publicClient>,
  paths: string[],
): Promise<string[]> {
  if (!paths.length) return [];
  const { data } = await sb.storage.from("listing-images").createSignedUrls(paths, 60 * 60);
  return (data ?? []).map((d) => d.signedUrl ?? "").filter(Boolean);
}

const SELLER_COLS =
  "id, display_name, dealership_name, avatar_url, whatsapp, location, verified";

export const getApprovedListings = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb
    .from("listings")
    .select(`*, seller:profiles!listings_seller_id_fkey(${SELLER_COLS})`)
    .eq("status", "approved")
    .order("tier", { ascending: false }) // premium_plus > premium > free
    .order("created_at", { ascending: false })
    .limit(120);
  if (error) throw new Error(error.message);
  const rows = (data ?? []) as unknown as DbListing[];
  for (const r of rows) r.image_urls = await signImages(sb, r.images ?? []);
  return rows;
});

export const getListingById = createServerFn({ method: "GET" })
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: row, error } = await sb
      .from("listings")
      .select(`*, seller:profiles!listings_seller_id_fkey(${SELLER_COLS})`)
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return null;
    const listing = row as unknown as DbListing;
    listing.image_urls = await signImages(sb, listing.images ?? []);
    return listing;
  });

export const getSellerListings = createServerFn({ method: "GET" })
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: prof } = await sb
      .from("profiles")
      .select(SELLER_COLS + ", bio")
      .eq("id", data.id)
      .maybeSingle();
    const { data: rows, error } = await sb
      .from("listings")
      .select("*")
      .eq("seller_id", data.id)
      .eq("status", "approved")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const listings = (rows ?? []) as unknown as DbListing[];
    for (const r of listings) r.image_urls = await signImages(sb, r.images ?? []);
    return { profile: prof as SellerSnippet & { bio: string | null } | null, listings };
  });

const CreateListingInput = z.object({
  kind: z.enum(["car", "part"]),
  title: z.string().min(3).max(120),
  description: z.string().min(10).max(2000),
  price: z.string().min(1).max(60),
  year: z.number().int().min(1950).max(2100).nullable().optional(),
  make: z.string().max(60).nullable().optional(),
  model: z.string().max(60).nullable().optional(),
  mileage: z.string().max(60).nullable().optional(),
  condition: z.string().max(60).nullable().optional(),
  location: z.string().min(2).max(120),
  images: z.array(z.string()).max(15),
});

export const createListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateListingInput.parse(d))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("listings")
      .insert({
        seller_id: context.userId,
        kind: data.kind,
        title: data.title,
        description: data.description,
        price: data.price,
        year: data.year ?? null,
        make: data.make ?? null,
        model: data.model ?? null,
        mileage: data.mileage ?? null,
        condition: data.condition ?? null,
        location: data.location,
        images: data.images,
        tier: "free",
        status: "pending",
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id as string };
  });

export const updateMyListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({ id: z.string().uuid() })
      .and(CreateListingInput.partial())
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { id, ...rest } = data;
    // Editing an approved listing returns it to pending for re-moderation
    const { error } = await context.supabase
      .from("listings")
      .update({ ...rest, status: "pending" as const })
      .eq("id", id)
      .eq("seller_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMyListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("listings")
      .delete()
      .eq("id", data.id)
      .eq("seller_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getMyListings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("listings")
      .select("*")
      .eq("seller_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const rows = (data ?? []) as unknown as DbListing[];
    const sb = publicClient();
    for (const r of rows) r.image_urls = await signImages(sb, r.images ?? []);
    return rows;
  });

// ===== PREMIUM+ AI PROMO IMAGE =====
// Generates a cinematic ad poster and stores it as the listing's promo_video_url.
// Note: app-runtime text-to-video is not currently exposed via the AI gateway —
// we render a high-impact AI promo poster that the UI animates into a teaser.
export const generatePromoVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { listingId: string }) =>
    z.object({ listingId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: listing, error } = await context.supabase
      .from("listings")
      .select("id, seller_id, tier, title, description, year, make, model, location, images")
      .eq("id", data.listingId)
      .maybeSingle();
    if (error || !listing) throw new Error("Listing not found");
    if (listing.seller_id !== context.userId) throw new Error("Not your listing");
    if (listing.tier !== "premium_plus") {
      throw new Error("AI promo generation is a Premium+ feature");
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI gateway not configured");

    // Use AI to write a punchy ad caption + (separately) generate an image via Lovable AI.
    const gateway = createLovableAiGatewayProvider(key);
    const { text: caption } = await generateText({
      model: gateway("google/gemini-2.5-flash"),
      prompt: `Write a 2-line punchy social media ad caption for this Jamaican vehicle listing. No hashtags.\nTitle: ${listing.title}\nDetails: ${listing.year ?? ""} ${listing.make ?? ""} ${listing.model ?? ""}\nLocation: ${listing.location}\nDescription: ${listing.description}`,
    });

    // Generate cinematic promo image via Lovable AI images endpoint
    const prompt = `Cinematic luxury car commercial poster, ${listing.year ?? ""} ${listing.make ?? ""} ${listing.model ?? ""}, dramatic golden-hour lighting, motion blur background, professional automotive photography, vibrant Jamaican setting, ultra detailed, 4k`;

    const imgResp = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        prompt,
        modalities: ["image", "text"],
      }),
    });
    if (!imgResp.ok) {
      const t = await imgResp.text();
      throw new Error(`AI image generation failed: ${imgResp.status} ${t.slice(0, 200)}`);
    }
    const imgJson = (await imgResp.json()) as {
      data?: Array<{ b64_json?: string; url?: string }>;
    };
    const b64 = imgJson.data?.[0]?.b64_json;
    const url = imgJson.data?.[0]?.url;
    let dataUrl: string;
    if (b64) dataUrl = `data:image/png;base64,${b64}`;
    else if (url) dataUrl = url;
    else throw new Error("No image returned from AI");

    // Upload to storage as the seller (RLS-friendly path)
    let promoPath: string;
    if (dataUrl.startsWith("data:")) {
      const [, base64] = dataUrl.split(",");
      const buf = Buffer.from(base64, "base64");
      promoPath = `${context.userId}/${listing.id}-promo-${Date.now()}.png`;
      const { error: upErr } = await context.supabase.storage
        .from("listing-images")
        .upload(promoPath, buf, { contentType: "image/png", upsert: true });
      if (upErr) throw new Error(upErr.message);
    } else {
      // Remote URL — fetch and re-upload
      const r = await fetch(url!);
      const buf = Buffer.from(await r.arrayBuffer());
      promoPath = `${context.userId}/${listing.id}-promo-${Date.now()}.png`;
      const { error: upErr } = await context.supabase.storage
        .from("listing-images")
        .upload(promoPath, buf, { contentType: "image/png", upsert: true });
      if (upErr) throw new Error(upErr.message);
    }

    await context.supabase
      .from("listings")
      .update({ promo_video_url: promoPath })
      .eq("id", listing.id);

    const sb = publicClient();
    const [signed] = await signImages(sb, [promoPath]);
    return { ok: true, promoUrl: signed, caption };
  });
