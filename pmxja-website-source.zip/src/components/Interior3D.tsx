import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, OrbitControls, ContactShadows, Html } from "@react-three/drei";
import { Suspense, useRef, useState } from "react";
import type { Group } from "three";

type View = "exterior" | "front" | "back";

function CarBody({
  view,
  doorsOpen,
  onClickDoor,
}: {
  view: View;
  doorsOpen: boolean;
  onClickDoor: () => void;
}) {
  const ref = useRef<Group>(null);
  useFrame((_, dt) => {
    if (view === "exterior" && ref.current) ref.current.rotation.y += dt * 0.15;
  });

  return (
    <group ref={ref}>
      {/* Body */}
      <mesh position={[0, 0.55, 0]} castShadow receiveShadow>
        <boxGeometry args={[3.8, 0.7, 1.6]} />
        <meshStandardMaterial color="#1e6fb8" metalness={0.7} roughness={0.25} />
      </mesh>
      {/* Cabin */}
      <mesh position={[0.1, 1.05, 0]} castShadow>
        <boxGeometry args={[2.2, 0.6, 1.45]} />
        <meshStandardMaterial color="#1e6fb8" metalness={0.7} roughness={0.25} />
      </mesh>
      {/* Windshield/windows */}
      <mesh position={[0.1, 1.06, 0]}>
        <boxGeometry args={[2.18, 0.5, 1.47]} />
        <meshPhysicalMaterial
          color="#a9d8ff"
          transmission={0.85}
          roughness={0.08}
          metalness={0.1}
          thickness={0.4}
          ior={1.45}
        />
      </mesh>
      {/* Doors */}
      {[-0.55, 0.55].map((z) => (
        <group key={z} position={[0.15, 0.6, z]} rotation={[0, doorsOpen ? (z > 0 ? -0.7 : 0.7) : 0, 0]}>
          <mesh onClick={onClickDoor} castShadow>
            <boxGeometry args={[1.6, 0.65, 0.05]} />
            <meshStandardMaterial color="#1a64a8" metalness={0.7} roughness={0.3} />
          </mesh>
        </group>
      ))}
      {/* Wheels */}
      {[
        [-1.3, 0.3, 0.8],
        [1.3, 0.3, 0.8],
        [-1.3, 0.3, -0.8],
        [1.3, 0.3, -0.8],
      ].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.32, 0.32, 0.25, 24]} />
          <meshStandardMaterial color="#111" roughness={0.6} />
        </mesh>
      ))}
      {/* Headlights */}
      <mesh position={[1.92, 0.65, 0.55]}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial emissive="#fff7c0" emissiveIntensity={1.2} color="#fff7c0" />
      </mesh>
      <mesh position={[1.92, 0.65, -0.55]}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial emissive="#fff7c0" emissiveIntensity={1.2} color="#fff7c0" />
      </mesh>
    </group>
  );
}

function FrontInterior() {
  return (
    <group>
      {/* Dashboard */}
      <mesh position={[0, 0.6, -0.6]} castShadow>
        <boxGeometry args={[2.4, 0.4, 0.4]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.8} />
      </mesh>
      {/* Steering wheel */}
      <mesh position={[-0.6, 0.55, -0.15]} rotation={[Math.PI / 2.4, 0, 0]}>
        <torusGeometry args={[0.22, 0.04, 12, 32]} />
        <meshStandardMaterial color="#222" roughness={0.5} />
      </mesh>
      {/* Shifter */}
      <mesh position={[0.05, 0.35, 0.1]} castShadow>
        <cylinderGeometry args={[0.04, 0.04, 0.3]} />
        <meshStandardMaterial color="#333" metalness={0.6} />
      </mesh>
      <mesh position={[0.05, 0.5, 0.1]}>
        <sphereGeometry args={[0.07, 16, 16]} />
        <meshStandardMaterial color="#a0a0a0" metalness={0.8} roughness={0.3} />
      </mesh>
      {/* Front seats */}
      {[-0.55, 0.55].map((x) => (
        <group key={x} position={[x, 0.4, 0.6]}>
          <mesh castShadow>
            <boxGeometry args={[0.55, 0.15, 0.6]} />
            <meshStandardMaterial color="#3a3a3a" roughness={0.7} />
          </mesh>
          <mesh position={[0, 0.45, -0.25]} castShadow>
            <boxGeometry args={[0.55, 0.9, 0.12]} />
            <meshStandardMaterial color="#3a3a3a" roughness={0.7} />
          </mesh>
        </group>
      ))}
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[3, 2.5]} />
        <meshStandardMaterial color="#1c2530" />
      </mesh>
    </group>
  );
}

function BackInterior() {
  return (
    <group>
      {/* Rear bench */}
      <mesh position={[0, 0.4, 0.2]} castShadow>
        <boxGeometry args={[1.9, 0.18, 0.8]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.85, -0.2]} castShadow>
        <boxGeometry args={[1.9, 0.9, 0.18]} />
        <meshStandardMaterial color="#3a3a3a" roughness={0.7} />
      </mesh>
      {/* Headrests */}
      {[-0.6, 0, 0.6].map((x) => (
        <mesh key={x} position={[x, 1.4, -0.18]} castShadow>
          <boxGeometry args={[0.4, 0.25, 0.18]} />
          <meshStandardMaterial color="#2a2a2a" roughness={0.8} />
        </mesh>
      ))}
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[2.8, 2]} />
        <meshStandardMaterial color="#1c2530" />
      </mesh>
    </group>
  );
}

export function Interior3D() {
  const [view, setView] = useState<View>("exterior");
  const [doorsOpen, setDoorsOpen] = useState(false);

  return (
    <div className="relative h-[520px] rounded-xl overflow-hidden bg-gradient-to-b from-sky-200 to-white shadow-soft">
      <Canvas shadows camera={{ position: [5, 2.2, 5], fov: 45 }}>
        <Suspense
          fallback={
            <Html center>
              <div className="text-sm text-muted-foreground">Loading 3D showroom…</div>
            </Html>
          }
        >
          <ambientLight intensity={0.5} />
          <directionalLight position={[5, 8, 5]} intensity={1.2} castShadow />
          <Environment preset="city" />
          {view === "exterior" && (
            <>
              <CarBody view={view} doorsOpen={doorsOpen} onClickDoor={() => setView("front")} />
              <ContactShadows position={[0, 0, 0]} opacity={0.4} blur={2} scale={10} />
            </>
          )}
          {view === "front" && <FrontInterior />}
          {view === "back" && <BackInterior />}
          <OrbitControls
            enablePan={false}
            minDistance={2.5}
            maxDistance={9}
            maxPolarAngle={Math.PI / 2.05}
          />
        </Suspense>
      </Canvas>

      <div className="absolute top-3 left-3 flex flex-wrap gap-2">
        {(["exterior", "front", "back"] as View[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium backdrop-blur transition-colors ${
              view === v ? "bg-primary text-primary-foreground" : "bg-white/80 text-foreground hover:bg-white"
            }`}
          >
            {v === "exterior" ? "Exterior 360°" : v === "front" ? "Front Cabin" : "Rear Cabin"}
          </button>
        ))}
      </div>

      {view === "exterior" && (
        <button
          onClick={() => setDoorsOpen((v) => !v)}
          className="absolute bottom-3 left-3 px-3 py-1.5 rounded-full bg-white/90 text-foreground text-xs font-medium hover:bg-white"
        >
          {doorsOpen ? "Close doors" : "Open doors"}
        </button>
      )}
      <div className="absolute bottom-3 right-3 px-3 py-1.5 rounded-full bg-black/60 text-white text-[11px] backdrop-blur">
        Drag to orbit · Pinch / scroll to zoom
      </div>
    </div>
  );
}
