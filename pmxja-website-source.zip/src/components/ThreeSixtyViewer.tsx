import { useEffect, useRef, useState } from "react";
import { RotateCw, ZoomIn, ZoomOut } from "lucide-react";

/**
 * Drag horizontally to spin through uploaded reference images, creating a
 * pseudo-360° showroom from a sequence of vehicle photos.
 */
export function ThreeSixtyViewer({ images }: { images: string[] }) {
  const [index, setIndex] = useState(0);
  const [zoom, setZoom] = useState(1);
  const startX = useRef<number | null>(null);
  const startIdx = useRef(0);

  useEffect(() => {
    if (images.length < 2) return;
    const id = setInterval(() => setIndex((i) => (i + 1) % images.length), 90);
    return () => clearInterval(id);
  }, [images.length === 0]); // eslint-disable-line

  const onDown = (clientX: number) => {
    startX.current = clientX;
    startIdx.current = index;
  };
  const onMove = (clientX: number) => {
    if (startX.current === null || images.length === 0) return;
    const delta = clientX - startX.current;
    const step = Math.round(delta / 12);
    const next = (((startIdx.current - step) % images.length) + images.length) % images.length;
    setIndex(next);
  };
  const onUp = () => (startX.current = null);

  if (images.length === 0) {
    return (
      <div className="aspect-video rounded-xl border-2 border-dashed border-border grid place-items-center text-sm text-muted-foreground bg-sky-soft">
        Upload reference images to build the 360° showroom.
      </div>
    );
  }

  return (
    <div className="relative aspect-video rounded-xl overflow-hidden bg-black select-none shadow-soft">
      <div
        className="absolute inset-0 cursor-grab active:cursor-grabbing"
        onMouseDown={(e) => onDown(e.clientX)}
        onMouseMove={(e) => onMove(e.clientX)}
        onMouseUp={onUp}
        onMouseLeave={onUp}
        onTouchStart={(e) => onDown(e.touches[0].clientX)}
        onTouchMove={(e) => onMove(e.touches[0].clientX)}
        onTouchEnd={onUp}
      >
        <img
          src={images[index]}
          alt={`Vehicle angle ${index + 1}`}
          className="w-full h-full object-contain transition-transform"
          style={{ transform: `scale(${zoom})` }}
          draggable={false}
        />
      </div>

      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 text-white text-xs flex items-center gap-1.5 backdrop-blur">
        <RotateCw className="h-3.5 w-3.5" /> Drag to rotate · {index + 1}/{images.length}
      </div>

      <div className="absolute bottom-3 right-3 flex flex-col gap-2">
        <button
          onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
          className="grid h-9 w-9 place-items-center rounded-full bg-white/90 text-foreground hover:bg-white"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <button
          onClick={() => setZoom((z) => Math.max(1, z - 0.2))}
          className="grid h-9 w-9 place-items-center rounded-full bg-white/90 text-foreground hover:bg-white"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
