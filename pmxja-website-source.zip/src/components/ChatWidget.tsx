import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { MessageCircle, Send, X, Phone } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const WHATSAPP = "18768598983";

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const transport = useRef(new DefaultChatTransport({ api: "/api/chat" })).current;
  const { messages, sendMessage, status } = useChat({ transport });

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  const loading = status === "submitted" || status === "streaming";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    sendMessage({ text: input.trim() });
    setInput("");
  };

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-hero text-primary-foreground shadow-soft hover:scale-105 transition-transform"
        aria-label="Open chat"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-5 z-50 w-[92vw] max-w-sm rounded-2xl border border-border bg-card shadow-soft overflow-hidden flex flex-col h-[70vh] max-h-[560px]">
          <div className="bg-hero text-primary-foreground px-4 py-3">
            <div className="font-semibold">Passard AI Concierge</div>
            <div className="text-xs opacity-90">Ask about cars, parts, or how to get listed.</div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3 bg-sky-soft">
            {messages.length === 0 && (
              <div className="text-sm text-muted-foreground">
                👋 Hi! I can help you find vehicles, list your car for free, or explain Premium plans.
                When you're ready to deal, I'll send you straight to a seller on WhatsApp.
              </div>
            )}
            {messages.map((m) => {
              const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
              return (
                <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm whitespace-pre-wrap ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-card text-foreground border border-border rounded-bl-sm"
                    }`}
                  >
                    {text}
                  </div>
                </div>
              );
            })}
            {loading && (
              <div className="text-xs text-muted-foreground animate-pulse">Concierge is typing…</div>
            )}
          </div>

          <a
            href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi, I'm interested in a listing on PassardAutoMediaJa.")}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 bg-[oklch(0.65_0.18_150)] text-white py-2.5 text-sm font-semibold hover:opacity-95"
          >
            <Phone className="h-4 w-4" /> Chat seller on WhatsApp
          </a>

          <form onSubmit={handleSubmit} className="flex items-center gap-2 p-2 border-t border-border bg-card">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your question…"
              className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="grid h-9 w-9 place-items-center rounded-md bg-primary text-primary-foreground disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
