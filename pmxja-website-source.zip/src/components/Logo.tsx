import logoAsset from "@/assets/pmxja-logo.png.asset.json";

export function Logo({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <img
      src={logoAsset.url}
      alt="PassardAutoMediaJa — PMxJA"
      className={`${className} object-contain`}
      width={40}
      height={40}
    />
  );
}

export const logoUrl = logoAsset.url;
