import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { Menu, X, LogOut, LayoutDashboard, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Logo } from "./Logo";
import { useAuth, signOut } from "@/lib/auth";

const publicLinks = [
  { to: "/", label: "Home" },
  { to: "/browse", label: "Browse" },
  { to: "/viewer", label: "3D Showroom" },
  { to: "/pricing", label: "Premium" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, isAdmin } = useAuth();
  const nav = useNavigate();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2.5 group">
          <Logo className="h-11 w-11" />
          <div className="leading-tight">
            <div className="text-[15px] font-bold tracking-tight text-foreground">
              Passard<span className="text-primary">AutoMediaJa</span>
            </div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              PMxJA · Cars · Parts · Jamaica
            </div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {publicLinks.map((l) => {
            const active = pathname === l.to;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`px-3 py-2 text-sm rounded-md transition-colors ${
                  active
                    ? "text-primary bg-secondary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {l.label}
              </Link>
            );
          })}

          {user ? (
            <>
              <Link
                to="/dashboard"
                className="px-3 py-2 text-sm rounded-md text-muted-foreground hover:text-foreground hover:bg-muted inline-flex items-center gap-1.5"
              >
                <LayoutDashboard className="h-4 w-4" /> Dashboard
              </Link>
              {isAdmin && (
                <Link
                  to="/admin"
                  className="px-3 py-2 text-sm rounded-md text-amber-700 hover:bg-amber-50 inline-flex items-center gap-1.5"
                >
                  <ShieldCheck className="h-4 w-4" /> Admin
                </Link>
              )}
              <button
                onClick={async () => {
                  await signOut();
                  nav({ to: "/" });
                }}
                className="ml-1 inline-flex items-center gap-1.5 rounded-md border border-input px-3 py-2 text-sm hover:bg-secondary"
                title="Sign out"
              >
                <LogOut className="h-4 w-4" /> Sign out
              </button>
              <Link
                to="/sell"
                className="ml-2 inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-soft hover:bg-primary/90"
              >
                Post Free Ad
              </Link>
            </>
          ) : (
            <>
              <Link
                to="/auth"
                className="ml-1 inline-flex items-center rounded-md border border-input px-3 py-2 text-sm hover:bg-secondary"
              >
                Sign in
              </Link>
              <Link
                to="/sell"
                className="ml-2 inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-soft hover:bg-primary/90"
              >
                Post Free Ad
              </Link>
            </>
          )}
        </nav>

        <button
          onClick={() => setOpen((v) => !v)}
          className="md:hidden p-2 rounded-md hover:bg-muted"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="mx-auto max-w-7xl px-4 py-2 flex flex-col">
            {publicLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="py-2.5 text-sm text-foreground"
              >
                {l.label}
              </Link>
            ))}
            <Link to="/sell" onClick={() => setOpen(false)} className="py-2.5 text-sm text-primary font-semibold">
              Post Free Ad
            </Link>
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setOpen(false)} className="py-2.5 text-sm">
                  Dashboard
                </Link>
                {isAdmin && (
                  <Link to="/admin" onClick={() => setOpen(false)} className="py-2.5 text-sm">
                    Admin
                  </Link>
                )}
                <button
                  onClick={async () => {
                    setOpen(false);
                    await signOut();
                    nav({ to: "/" });
                  }}
                  className="py-2.5 text-sm text-left"
                >
                  Sign out
                </button>
              </>
            ) : (
              <Link to="/auth" onClick={() => setOpen(false)} className="py-2.5 text-sm">
                Sign in
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-sky-soft mt-16">
      <div className="mx-auto max-w-7xl px-4 py-10 grid gap-8 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <Logo className="h-10 w-10" />
            <div className="font-bold text-lg text-foreground">PassardAutoMediaJa</div>
          </div>
          <p className="text-sm text-muted-foreground mt-3 max-w-xs">
            Jamaica's friendliest place to advertise vehicles & auto parts. Free for dealers.
          </p>
        </div>
        <div className="text-sm">
          <div className="font-semibold mb-2">Contact</div>
          <a className="block text-muted-foreground hover:text-primary" href="mailto:passardmediaja@gmail.com">
            passardmediaja@gmail.com
          </a>
          <a
            className="block text-muted-foreground hover:text-primary"
            href="https://wa.me/18768598983"
            target="_blank"
            rel="noreferrer"
          >
            WhatsApp: +1 (876) 859-8983
          </a>
        </div>
        <div className="text-sm">
          <div className="font-semibold mb-2">Quick Links</div>
          <Link to="/browse" className="block text-muted-foreground hover:text-primary">Browse Cars & Parts</Link>
          <Link to="/sell" className="block text-muted-foreground hover:text-primary">Post a Free Ad</Link>
          <Link to="/pricing" className="block text-muted-foreground hover:text-primary">Premium & Premium+</Link>
        </div>
      </div>
      <div className="border-t border-border/60 py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} PassardAutoMediaJa. All rights reserved.
      </div>
    </footer>
  );
}
